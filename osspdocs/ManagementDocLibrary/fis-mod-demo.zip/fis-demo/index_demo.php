<!doctype html>
<html>
	<head>
		<title>一个简单的fis模块化的demo</title>
	</head>
	<body>
		<h1>一个简单的demo</h1>
		<p>随便写点东西,如果你引入的是通用的全站一些js可以考虑用php的include方法引入</p>
		<?php
			//如果你引入的是通用的全站一些js可以考虑用php的include方法引入
			include("libs_js.php");
		?>
		
		<!--下面这个注释是放编译后的js的位置的-->	
			<!--SCRIPT_PLACEHOLDER-->
			<!--RESOURCEMAP_PLACEHOLDER-->
		<script>
			var index = require("index");
			index.init("我的测试简单就好");
			console.log(index.date);
		</script>
	</body>
</html>