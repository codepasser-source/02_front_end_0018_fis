<script src="static/libs/mod.js"></script>
<script src="static/libs/vue.min.js"></script>