//var fis = module.exports = require('fis');
// 开起 autuload, 好处是，依赖自动加载。
//npm install fis-postpackager-require-async -g 
fis.config.merge({
	statics : 'static',
	modules : {
		parser : {
			less : 'less',
			tmpl : 'utc'
		},
		postprocessor : {
			js : "jswrapper, require-async",
			html : "require-async"
		},
		postpackager : ['autoload', 'simple'],
		lint : {
			js : 'jshint'
		}
	},
	settings : {
		postprocessor : {
			jswrapper : {
				type : 'amd'
			}
		},
		lint : {
			jshint : {
				camelcase : true,
				curly : true,
				eqeqeq : true,
				forin : true,
				immed : true,
				latedef : true,
				newcap : true,
				noarg : true,
				noempty : true,
				node : true
			}
		}
	}
});

fis.config.set('roadmap.path', [

    // {
        // reg: /libs/i,
		// isMod:false
        // release: false
    // },
	
    // 标记 isMod 为 true, 这样，在 modules 里面的满足 commonjs 规范的 js 会自动包装成 amd js, 以至于能在浏览器中运行。
    //
    {
        reg: /js\/([^\/]+)\/([^.]+)\.js$/i,
        isMod: true,
        id: "$2",//模块的id
        release: '/static\/js\/$1/\$2\.js'//这里是产出的文件引用路径
    }
]);
