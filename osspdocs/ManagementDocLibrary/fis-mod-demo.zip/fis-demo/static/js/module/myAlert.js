/* global define */
//define("myAlert",  function(require, exports, module){
//这个define可以不写编译的时候fis会自动帮你加上
	 var o = {};
	 o.confirm = function(str){
		 //xxxx这里写自己一些业务逻辑
		 return confirm(str);
	 }
	  module.exports=o;
//})