<!doctype html>
<html>
	<head>
		<title>一个简单的fis模块化的demo</title>
	
</head>
	<body>
		<h1>一个简单的demo</h1>
		<p>随便写点东西</p>
		<?php
			include("libs_js.php");
		?>
		<script src="/static/libs/mod_1c8526c.js"></script>
		<script src="/static/libs/vue.min_eb54046.js"></script>
		<!--下面这个注释是放编译后的js的位置的-->	
			<script type="text/javascript" src="/static/js/module/myAlert_77208f8.js"></script>
<script type="text/javascript" src="/static/js/app/index_13a3448.js"></script>

			
		<script>
			var index = require("index");
			index.init("我的测试理解意思就行");
		</script>
	</body>
</html>