<script src="/static/libs/mod_1c8526c.js"></script>
<script src="/static/libs/vue.min_eb54046.js"></script>