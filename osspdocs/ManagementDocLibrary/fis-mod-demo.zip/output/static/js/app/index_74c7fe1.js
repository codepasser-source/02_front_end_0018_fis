define('index', function(require, exports, module){

/* global define */
define("index",  function(require, exports, module){
	var b = require("myAlert");
	var o = {};
	var name="myname";
	o.init = function(str){
		b.confirm(name+str);
	};
	 module.exports=o;
});

});