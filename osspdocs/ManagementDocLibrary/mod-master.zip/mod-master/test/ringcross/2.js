define('ringcross/2.js', function(require, exports, module){
//------------------------------------------------------------

exports.test = function() {
};

exports.val = 200;

var m1 = require('ringcross/1.js');
var m2 = require('ringcross/2.js');
var m3 = require('ringcross/3.js');

//------------------------------------------------------------
});
