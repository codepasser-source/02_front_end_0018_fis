define('complex/root1.js', function(require, exports, module){
	var root1_1 = require('complex/root1-1.js');
	var rootCommon = require('complex/root1-common.js');

	module.exports = {
		'rootCommon': rootCommon,
		'root1_1': root1_1
	};

});