define('complex/root1-1.js',function(require, exports, module){
	exports.say = function() {
		return '1-1';
	}
});
