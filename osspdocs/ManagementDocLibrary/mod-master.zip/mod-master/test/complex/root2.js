define('complex/root2.js', function(require, exports, module){
	var root1_3 = require('complex/root1-3.js');
	var rootCommon = require('complex/root1-common.js');

	module.exports = {
		'root1_3': root1_3,
		'rootCommon': rootCommon
	}
});
