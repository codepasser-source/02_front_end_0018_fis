define('complex/root1-common.js', function(require, exports, module){
	exports.say = function() {
		return 'common';
	}
});
