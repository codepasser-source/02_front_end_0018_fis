define('asynctest1/1.js', function(require, exports, module){
//------------------------------------------------------------

module.exports = {
	say: function() {
	    return 123;
	}
};

//------------------------------------------------------------
});
