define('asyncmore/1.js', function(require, exports, module){
//------------------------------------------------------------

exports.test = function() {
	return 1;
};

//------------------------------------------------------------
});
