define('asyncmore/2.js', function(require, exports, module){
//------------------------------------------------------------

exports.test = function() {
	return 2;
};

//------------------------------------------------------------
});
