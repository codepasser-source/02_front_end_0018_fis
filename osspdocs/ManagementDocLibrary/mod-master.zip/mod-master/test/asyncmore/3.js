define('asyncmore/3.js', function(require, exports, module){
//------------------------------------------------------------

exports.test = function() {
	return 3;
};

//------------------------------------------------------------
});
