define('multi/1.js', function(require, exports, module){
//------------------------------------------------------------

module.exports = {
	num: function() {
	    return 1;
	}
};

//------------------------------------------------------------
});
