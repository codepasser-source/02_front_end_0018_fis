define('multi/2.js', function(require, exports, module){
//------------------------------------------------------------

exports.num = function(speed) {
    return 2;
};


//------------------------------------------------------------
});
