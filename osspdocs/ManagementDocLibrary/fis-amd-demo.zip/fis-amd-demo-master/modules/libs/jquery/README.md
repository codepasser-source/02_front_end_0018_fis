Component 说明
=======================

来源：bower
名称：jquery
版本：2.1.1