说明
===================

amd loader 任选其一：

- esl.js
- require.js
- mod-amd.js
